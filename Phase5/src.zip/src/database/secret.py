DB_NAME = 'defaultdb'
DB_USER = 'avnadmin'
DB_PASSWORD = 'AVNS_QXs1v9qBTveDtLIXZfW'
DB_HOST = 'mysql-374f4726-majidnamiiiii-e945.a.aivencloud.com'
DB_PORT = '11741'
DB_URL = "mysql://avnadmin:AVNS_QXs1v9qBTveDtLIXZfW@mysql-374f4726-majidnamiiiii-e945.a.aivencloud.com:11741/defaultdb?ssl-mode=REQUIRED"