from django.apps import AppConfig


class Group5Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'group5'
