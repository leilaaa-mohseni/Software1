from django.apps import AppConfig


class Group2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'group2'
